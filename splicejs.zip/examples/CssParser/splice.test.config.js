/* Location of SpliceJS relative to applications' URL */
var SPLICE_PUBLIC_ROOT = '../../splicejs';

/*
 * When set to "true" preloader will not be shown
 * */
var SPLICE_SUPPRESS_PRELOADER = false;


/*
	Plaform configuration flag
	set to true if deploying in mobile space
 */
var SPLICE_PLATFORM_IS_MOBILE  = false;

var SPLICE_PLATFORM_IS_TOUCH_ENABLED = true;